﻿namespace RESTServiceProject.Models
{
    public class UserObject
    {
        public int userID { get; set; }
        public string userEmail { get; set; }
        public string userPassword { get; set; }
        public DateTime createdDate { get; set; }
    }
}
